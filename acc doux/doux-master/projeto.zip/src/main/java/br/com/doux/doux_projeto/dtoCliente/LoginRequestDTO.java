package br.com.doux.doux_projeto.dtoCliente;

public record LoginRequestDTO (String nomeCliente, String emailCliente, String senhaCliente){

}
