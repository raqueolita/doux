package br.com.doux.doux_projeto.dtoCliente;

public record  ResponseDTO (String nomeCliente, String token) {

}
