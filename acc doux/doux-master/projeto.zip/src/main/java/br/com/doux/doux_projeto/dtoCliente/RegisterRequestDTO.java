package br.com.doux.doux_projeto.dtoCliente;

public record  RegisterRequestDTO (String nomeCliente, String emailCliente, String senhaCliente){

}
